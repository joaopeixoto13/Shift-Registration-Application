=============================================================
==   Se fôr criar um projeto, dar o nome de: ProjectoATC2  ==
==   Adicionar as configurações para o FCGI                ==
==   Na pasta 'htdocs', colocar a pasta: projeto           ==
=============================================================

# Projecto
Repositótio do Projecto de ATC2

## Elementos do Grupo PL3-01

```
91983	Constantino José Oliveira Sousa
91996	Diogo Roseira Silvino
91960	Joao Miguel Freitas Peixoto
88192	José da Cunha Fernandes
```


## Requisitos
# Fase 1 - Configuração dos Turnos e dos Alunos inscritos na UC
```
- No mínimo, cada aluno deve possuir um nome e um número mecanográfico.
- O nome não pode conter dígitos e o número mecanográfico não pode conter outra coisa que dígitos.
- O Estatuto Especial, como o próprio nome indica, pode não existir, contudo, se existir, terá de ser um EE válido:
      - TE (Trabalhador Estudante);
      - AAC (Atleta de Alta Competição);
      - PDEF (Portador de Deficiência);
      - DAE (Dirigente Associativo);
      - DLG (???)
- No que toca à configuração dos Alunos inscritos na UC, este pode ser realizado por 2 formas:
      - Em Lote, onde é recebido um ficheiro com os alunos inscritos na UC;
      - Manualmente, onde oferece a possibilidade de adicionar um Aluno à UC em questão.
- Todos estes dados são sujeitos a um processo rigoroso de validação, em que são detetados todos os erros ocorrentes e indicando, no caso
  dos ficheiros, a(s) linha(s) em que esses erros ocorreram, bem como o motivo dos mesmos.
- São casos de erros:
      - Inválida Sintaxe do ficheiro;
      - Falta de algum campo obrigatório (nome ou número mecanográfico);
      - Nome e Número mecanográfico inválidos;
      - Estatuto Especial inválido;
      - Aluno repetido;
      - ...
- No final de processar toda esta informação, caso o ficheiro estiver corretamente formatado e sem nenhuma anomalia, é emitida uma mensagem de sucesso e o registo dos 
  alunos na UC é realizado.
  Caso exista algum tipo de anomalia/erro, são reportados todos os eventuais erros de forma a tornar o sistema o mais seguro possível e permitindo ao Docente verificar as
  anomalias ocorrentes, bem como a linha em que ocorreu.
- No que concerne à configuração dos Turnos, estes podem ser configurados de forma:
      - Automática, isto é, recebendo um ficheiro com todos os turnos (Nome e Número de vagas);
      - Manual, onde podemos definir o número de turnos, nome e número de vagas disponíveis para cada Turno
- Todos estes dados são devidamente verificados, nomeadamente a sintaxe do ficheiro recebido, a existência de turnos com vagas vazias, com números negativos ...
  Nota: O nome dos turnos não é obrigatório, por defeito, assumimos PL1, PL2, PL3 ... , consoante o número de turnos.
- Outras funcionalidades extras:
      - Possibilidade de remover um Aluno da lista de Alunos da UC;
      - Possibilidade de encontrar/saber se um determinado Aluno consta na Lista de Inscritos na UC;
      - Possibilidade de consultar o estado das Inscrições (Número de Alunos inscritos e informações dos turnos);
      - Aviso Automático no que toca à possibilidade da quantidade dos Alunos inscritos já na UC ser superior às vagas totais dos turnos;
      - Possibilidade de retomar as Inscrições a qualquer momento;
      - Possibilidade de dar reset e começar um novo ciclo de Inscrições
```

# Fase 2 - Marcações
```
- Etapa responsável pela marcação dos alunos da UC em questão (configurados na Fase 1), nos turnos, também estes configurados na Fase 1
- Possibilidade de o utilizador escolher entre os dois modos (Configuração ou Marcação)
- Ao entrar no menu que diz respeito às marcações, tem de obrigatoriamente:
      - Ter alunos inscritos na UC;
      - Ter turnos configurados;
      - O número de Vagas totais nos turnos ser superior ou igual ao número de alunos inscritos na UC;
- Todos os erros descritos acima são reportados ao utilizador de modo a tornar o programa o mais mais interativo e seguro possível.
- Outro aspeto importante é que, quando escolhido o modo 2 (Marcações), o utlizador não poderá voltar a alterar nas configurações da UC, isto é, quando feita alguma marcação, 
  o utilizador não poderá mudar os registos da UC, podendo comprometer todo o programa.
- No que diz respeito às marcações propriamente ditas, estas podem ser realizadas de duas formas:
      - Em lote, em que é recebido um ficheiro com a data, número, nome e as preferências de cada aluno listado no ficheiro;
      - Manual, em que cada utilizador poderá realizar a sua inscrição manualmente.
- Todos estes dados são sujeitos a um processo rigoroso de validação, em que são detetados todos os erros ocorrentes e indicando, no caso
  dos ficheiros, a(s) linha(s) em que esses erros ocorreram, bem como o motivo dos mesmos.
- São casos de erros:
      - Inválida Sintaxe do ficheiro;
      - Falta de algum campo;
      - Data inexistente/mal formatada;
      - Aluno que não consta no registo de alunos da UC;
      - Preferências/nomes dos turnos incorretos;
      - ...
- Todas as marcações possuem algum tipo de feedback, podendo estas ser mensagens de erro/anomalia (como descritas acima), ou de sucesso.
- No caso de uma marcação ser efetuada com sucesso, esta pode possuir duas formas distintas:
      - Um aluno não prioritário realizou uma marcação (ou via ficheiro) corretamente e confirma-mos a marcação em questão;
      - Um aluno prioritário realizou uma marcação (ou via ficheiro) corretamente e confirma-mos o turno que ficou colocado
- Todas estas marcações são etiquetadas temporalmente, isto é, a cada inscrição (manualmente), é gerado a data correpondente à marcação;
- No caso de alunos que realizam mais que uma marcação, prevalece a última;
- Outras funcionalidades extras:
      - Possibilidade de remover um Aluno dos Turnos/Marcações;
      - Possibilidade de encontrar/saber se um Aluno consta nas Marcações ou se já está alojado num determinado Turno (Aluno Prioritário); 
      - Possibilidade de consultar o estado das Marcações (Número de Alunos já registados e número de alunos (prioritários) já alocados nos turnos);
      - Consulta em tempo real de quantas vagas ainda exitem, com os alunos prioritários já nos seus devidos turnos;
      - Possibilidade de retomar as Marcações;
      - Possibilidade de dar reset e começar um novo ciclo de Inscrições e Marcações
```

# Fase 3 - Geração dos Turnos
```
- Compreende-se por geração dos turnos o processo de integrar cada Aluno inscrito na UC (Fase 1) que efetuou uma inscrição válida (Fase 2) no respetivo Turno
- Quando o Docente escolher esta opção, é validado um conjunto de situações:
      - Só poderá entrar neste modo se efetuou as restantes etapas com sucesso;
      - Só poderá entrar neste modo se efetuou pelo menos uma Marcação com sucesso;
      - Aviso no que toca à possibilidade de iniciar o processo de geração dos turnos e ainda haver inscrições por fazer (Alunos registados na UC que não 
        fizeram a sua Marcação)
            - Oportunidade de Abortar a Geração de Turnos e por ventura inscrever/notificar os Alunos que ainda não fizeram a sua Marcação;
            - Oportunidade de iniciar o processo de Geração de Turnos
- No que concerne ao processo/algoritmo de geração de turnos, este é subdividido em duas partes:
      - Os alunos com estatuto especial têm prioridade face aos demais, ficando imediatamente colocados no respetivo Turno (feedback logo após a Marcação - Fase 2);
      - Alunos sem Estatuto Especial sujeitos a uma alocação temporal, isto é, aquando a marcação, estas são etiquetadas temporalmente (Fase 2). 
        Quando se dá inicio ao processo de gerar os turnos, prevalecem/possuem vantagem as marcações efetuadas temporalmente primeiro, e assim sucessivamente.
- É gerado os ficheiros correpondestes a cada Turno, bem como um ficheiro de Report de erros, indicando, por exemplo, que um determinado Aluno não ficou colocado
  no(s) turno(s) uma vez que já não havia vagas para o(s) mesmo(s).
- No final, todos os ficheiros previmanete carregados são apgados, de modo a poder começar uma nova sessão.
- Outras funcionalidades extas:
      - Possibilidade de escolher o diretório/pasta dos ficheiros gerados (Turnos + Report);
      - Aviso no que toca à possibilidade de algum aluno constar na lista da UC mas ainda não ter realizado a sua Marcação nos Turnos; 
      - Reset automático de forma a poder começar imediatamente um novo ciclo de Inscrições e Marcações para outra UC

```
