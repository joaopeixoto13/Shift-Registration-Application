#pragma once
#include "AbstractMenu.h"

class WebRegisterShiftsManual1 : public AbstractMenu
{
public:
	void process();
};

