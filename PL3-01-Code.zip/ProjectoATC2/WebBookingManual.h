#pragma once
#include "AbstractMenu.h"
class WebBookingManual : public AbstractMenu
{
public:
	void process();
};

