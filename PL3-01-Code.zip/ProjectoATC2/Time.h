#ifndef TIME_H
#define TIME_H
#define _CRT_SECURE_NO_WARNINGS
#include <string>
#include <ctime>

using namespace std;

class Time
{
public:
	static string timeNow();

};

#endif