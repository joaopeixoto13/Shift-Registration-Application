#pragma once
#include "AbstractMenu.h"
class WebBookingFind : public AbstractMenu
{
public:
	void process();
};

