#pragma once
#include "AbstractMenu.h"

class WebRegisterShiftsFile : public AbstractMenu
{
public:
	void process();
};

