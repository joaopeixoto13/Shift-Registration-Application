#pragma once
#include <iostream>

using namespace std;

class Info
{
public:
	static void print(const string& x);
};

