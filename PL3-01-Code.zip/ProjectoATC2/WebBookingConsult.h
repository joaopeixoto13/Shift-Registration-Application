#pragma once
#include "AbstractMenu.h"

class WebBookingConsult : public AbstractMenu
{
public:
	void process();
};

