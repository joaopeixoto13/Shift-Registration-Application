#pragma once
#include "AbstractMenu.h"

class WebRegister : public AbstractMenu
{
public:
	void process();
};

