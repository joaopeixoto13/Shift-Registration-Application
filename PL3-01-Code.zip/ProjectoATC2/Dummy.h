#pragma once
#include "AbstractMenu.h"

class Dummy : public AbstractMenu
{
public:
	void process();
};

